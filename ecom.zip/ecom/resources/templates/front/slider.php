<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                                <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                            </ol>
                            <div class="carousel-inner">
                                <div class="item active">
                                    <img class="slide-image" src="https://www.stockland.com.au/~/media/shopping-centre/stockland-bundaberg/stores/jay-jays/jay-jays-header-800x300.jpg" alt="">
                                </div>
                                <div class="item">
                                    <img class="slide-image" src="https://cms.contactmedia.co.za/image/b9bb6b1862d506ce76cb5a8a1a6a3d04.800x300%7C.jpeg" alt="">
                                </div>
                                <div class="item">
                                    <img class="slide-image" src="http://funkys.tapas070.com/wp-content/uploads/2018/10/%5E74CE17AD5745C7A1A7F5E546C492B1C3D2B75EFB25C407D4B5%5Epimgpsh_fullsize_distr-800x300.jpg" alt="">
                                </div>
                            </div>
                            <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                                <span class="glyphicon glyphicon-chevron-left"></span>
                            </a>
                            <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                                <span class="glyphicon glyphicon-chevron-right"></span>
                            </a>
                        </div>