<?php require_once("../resources/config.php"); ?>

<?php include("../resources/templates/front/"."header.php"); ?>

    <!-- Page Content -->
    <div class="container">

        <div class="row">

           <!--Categories here-->
            <?php include("../resources/templates/front/"."side_nav.php"); ?>
            <!--Categories here-->

            <div class="col-md-9">

                <div class="row carousel-holder">

                    <div class="col-md-12">
                        <!--Carouse-->
                        <?php include("../resources/templates/front/"."slider.php"); ?>
                        <!--Carouse ends here-->
                    </div>

                </div>

                <div class="row">
                    
                    
                    <?php  get_products();  ?>

                    


                    

                    
                </div> <!--Row ends here-->

            </div>

        </div>

    </div>
    <!-- /.container -->

<?php include("../resources/templates/front/". "footer.php"); ?>

    
