<?php require_once("../resources/config.php"); ?>
<?php include("../resources/templates/front/"."header.php"); ?>

<?php

    process_transaction();

?>

    <!-- Page Content -->
    <div class="container">

        <h1 class="text-center">THANK YOU</h1>

    </div>
    <!-- /.container -->

<?php include("../resources/templates/front/". "footer.php"); ?>
  